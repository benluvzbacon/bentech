package com.bentech.world;

import com.bentech.BenTech;
import com.bentech.api.Material;
import com.bentech.api.Materials;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

/**
 * Attaches the ore {@link class_6796}s (defined as vanilla datapack JSONs in
 * {@code data/bentech/worldgen}) to the overworld. The actual feature JSONs are
 * data-driven, so only the biome hook lives in Java.
 */
public final class ModWorldgen {

    private ModWorldgen() {
    }

    public static void register() {
        class_2893.class_2895 step = class_2893.class_2895.field_13176;
        for (Material m : Materials.withOre()) {
            if (m.ore == null) {
                continue;
            }
            String name = "ore_" + m.getName();
            class_5321<class_6796> key = class_5321.method_29179(class_7924.field_41245, BenTech.id(name));
            BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), step, key);
        }
    }
}
