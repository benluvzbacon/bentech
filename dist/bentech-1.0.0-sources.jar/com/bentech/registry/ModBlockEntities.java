package com.bentech.registry;

import com.bentech.BenTech;
import com.bentech.block.entity.GeneratorBlockEntity;
import com.bentech.block.entity.ProcessingMachineBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Registers the two block entity types used by all machines.
 */
public final class ModBlockEntities {

    public static final class_2591<ProcessingMachineBlockEntity> PROCESSING = register(
            "processing_machine",
            class_2591.class_2592.method_20528(
                    ProcessingMachineBlockEntity::new,
                    ModBlocks.MACERATOR,
                    ModBlocks.ELECTRIC_FURNACE,
                    ModBlocks.ALLOY_SMELTER,
                    ModBlocks.COMPRESSOR).build());

    public static final class_2591<GeneratorBlockEntity> GENERATOR = register(
            "generator",
            class_2591.class_2592.method_20528(GeneratorBlockEntity::new, ModBlocks.GENERATOR).build());

    private ModBlockEntities() {
    }

    private static <T extends class_2586> class_2591<T> register(String path, class_2591<T> type) {
        class_2960 id = class_2960.method_60655(BenTech.MOD_ID, path);
        return class_2378.method_10230(class_7923.field_41181, id, type);
    }
}
