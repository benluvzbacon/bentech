package com.bentech.registry;

import com.bentech.BenTech;
import com.bentech.api.Material;
import com.bentech.api.Materials;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * A single creative tab containing every material form, machine and component
 * so the whole progression loop is explorable.
 */
public final class ModCreativeTab {

    private ModCreativeTab() {
    }

    public static void load() {
        class_1761 tab = FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup.bentech"))
                .method_47320(() -> new class_1799(Materials.Iron.dust == null ? Materials.Iron.ingot : Materials.Iron.dust))
                .method_47317((params, output) -> {
                    output.method_45420(new class_1799(ModBlocks.MACERATOR));
                    output.method_45420(new class_1799(ModBlocks.ELECTRIC_FURNACE));
                    output.method_45420(new class_1799(ModBlocks.ALLOY_SMELTER));
                    output.method_45420(new class_1799(ModBlocks.COMPRESSOR));
                    output.method_45420(new class_1799(ModBlocks.GENERATOR));
                    output.method_45420(new class_1799(ModItems.MACHINE_CASING));
                    output.method_45420(new class_1799(ModItems.BASIC_CIRCUIT));
                    output.method_45420(new class_1799(ModItems.ADVANCED_CIRCUIT));
                    output.method_45420(new class_1799(ModItems.ELECTRIC_MOTOR));
                    output.method_45420(new class_1799(ModItems.ELECTRIC_PUMP));
                    output.method_45420(new class_1799(ModItems.CAPACITOR));
                    for (Material m : Materials.all()) {
                        accept(output, m.dust);
                        accept(output, m.ingot);
                        accept(output, m.nugget);
                        accept(output, m.plate);
                        accept(output, m.rod);
                        accept(output, m.gear);
                        accept(output, m.ore);
                        accept(output, m.blockItem);
                    }
                })
                .method_47324();
        class_2960 id = class_2960.method_60655(BenTech.MOD_ID, "main");
        class_2378.method_10230(class_7923.field_44687, id, tab);
    }

    private static void accept(class_1761.class_7704 output, class_1792 item) {
        if (item != null) {
            output.method_45420(new class_1799(item));
        }
    }
}
