package com.bentech.registry;

import com.bentech.BenTech;
import com.bentech.api.Material;
import com.bentech.api.Materials;
import com.bentech.item.MaterialItem;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Registers every material-form item and the machine component items.
 * Forms: dust, ingot, nugget, plate, rod, gear. The corresponding ore / block
 * items are registered by {@link ModBlocks} so that placement works.
 */
public final class ModItems {

    public static final class_1792 MACHINE_CASING = register("machine_casing", new class_1792(plain(64)));
    public static final class_1792 BASIC_CIRCUIT = register("basic_circuit", new class_1792(plain(64)));
    public static final class_1792 ADVANCED_CIRCUIT = register("advanced_circuit", new class_1792(plain(64)));
    public static final class_1792 ELECTRIC_MOTOR = register("electric_motor", new class_1792(plain(64)));
    public static final class_1792 ELECTRIC_PUMP = register("electric_pump", new class_1792(plain(64)));
    public static final class_1792 CAPACITOR = register("capacitor", new class_1792(plain(64)));

    private ModItems() {
    }

    private static class_1792.class_1793 plain(int maxStack) {
        return new class_1792.class_1793().method_7889(maxStack);
    }

    private static <T extends class_1792> T register(String path, T item) {
        class_2960 id = class_2960.method_60655(BenTech.MOD_ID, path);
        class_2378.method_10230(class_7923.field_41178, id, item);
        return item;
    }

    public static void load() {
        // Material forms
        for (Material m : Materials.all()) {
            m.dust = register(m.getName() + "_dust", new MaterialItem(m, "dust", plain(64)));
            m.ingot = register(m.getName() + "_ingot", new MaterialItem(m, "ingot", plain(64)));
            m.nugget = register(m.getName() + "_nugget", new MaterialItem(m, "nugget", plain(64)));
            m.plate = register(m.getName() + "_plate", new MaterialItem(m, "plate", plain(64)));
            m.rod = register(m.getName() + "_rod", new MaterialItem(m, "rod", plain(64)));
            m.gear = register(m.getName() + "_gear", new MaterialItem(m, "gear", plain(64)));
        }
    }

    /** Helper to retrieve a material form item if it exists. */
    public static class_1792 form(Material m, String form) {
        Function<Material, class_1792> getter;
        switch (form) {
            case "dust" -> getter = mat -> mat.dust;
            case "ingot" -> getter = mat -> mat.ingot;
            case "nugget" -> getter = mat -> mat.nugget;
            case "plate" -> getter = mat -> mat.plate;
            case "rod" -> getter = mat -> mat.rod;
            case "gear" -> getter = mat -> mat.gear;
            default -> getter = mat -> mat.ingot;
        }
        return getter.apply(m);
    }
}
