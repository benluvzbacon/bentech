package com.bentech.registry;

import com.bentech.BenTech;
import com.bentech.api.Material;
import com.bentech.api.Materials;
import com.bentech.block.MachineBlock;
import com.bentech.block.MachineType;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

/**
 * Registers machine blocks, metal blocks and ore blocks.
 */
public final class ModBlocks {

    public static final MachineBlock MACERATOR = machine(MachineType.MACERATOR);
    public static final MachineBlock ELECTRIC_FURNACE = machine(MachineType.ELECTRIC_FURNACE);
    public static final MachineBlock ALLOY_SMELTER = machine(MachineType.ALLOY_SMELTER);
    public static final MachineBlock COMPRESSOR = machine(MachineType.COMPRESSOR);
    public static final MachineBlock GENERATOR = machine(MachineType.GENERATOR);

    private ModBlocks() {
    }

    public static void load() {
        for (Material m : Materials.all()) {
            if (m.block == null) {
                class_2248 metal = new class_2248(metalProperties());
                m.blockItem = registerBlockItem(metal, "block_" + m.getName());
                m.block = metal;
            }
            if (m.hasOre() && m.oreBlock == null) {
                class_2248 ore = new class_2248(oreProperties());
                m.ore = registerBlockItem(ore, "ore_" + m.getName());
                m.oreBlock = ore;
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private static MachineBlock machine(MachineType type) {
        MachineBlock block = new MachineBlock(machineProperties(), type);
        registerBlock(block, type.getId());
        return block;
    }

    private static void registerBlock(class_2248 block, String path) {
        class_2960 id = id(path);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
    }

    private static class_1747 registerBlockItem(class_2248 block, String path) {
        class_2960 id = id(path);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_1747 item = new class_1747(block, new class_1792.class_1793());
        class_2378.method_10230(class_7923.field_41178, id, item);
        return item;
    }

    private static class_4970.class_2251 machineProperties() {
        return class_4970.class_2251.method_9637().method_9629(2.0f, 6.0f).method_29292();
    }

    private static class_4970.class_2251 metalProperties() {
        return class_4970.class_2251.method_9637().method_9629(4.0f, 6.0f).method_29292();
    }

    private static class_4970.class_2251 oreProperties() {
        return class_4970.class_2251.method_9637().method_9629(3.0f, 3.0f).method_29292();
    }

    private static class_2960 id(String path) {
        return class_2960.method_60655(BenTech.MOD_ID, path);
    }
}
