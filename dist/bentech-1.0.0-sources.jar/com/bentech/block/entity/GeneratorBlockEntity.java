package com.bentech.block.entity;

import com.bentech.block.MachineType;
import com.bentech.registry.ModBlockEntities;
import com.bentech.util.MachineRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/**
 * A combustion generator. It burns fuel from its input slot to fill its own
 * energy buffer and pushes EU into adjacent machines — a simple energy "grid".
 */
public class GeneratorBlockEntity extends AbstractMachineBlockEntity {

    private final class_1799[] items = {class_1799.field_8037, class_1799.field_8037, class_1799.field_8037};
    public int burnTicksLeft;

    public GeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.GENERATOR, pos, state);
    }

    @Override
    protected class_1799 getSlotItem(int slot) {
        return slot >= 0 && slot < items.length ? items[slot] : class_1799.field_8037;
    }

    @Override
    protected void setSlotItem(int slot, class_1799 stack) {
        if (slot >= 0 && slot < items.length) {
            items[slot] = stack;
        }
    }

    @Override
    public long getMaxEnergy() {
        return MachineRecipes.maxEnergy(MachineType.GENERATOR);
    }

    @Override
    public boolean isActive() {
        return burnTicksLeft > 0;
    }

    @Override
    public void tickServer(class_1937 level, class_2338 pos, class_2680 state) {
        if (level == null || level.method_8608()) {
            return;
        }
        int output = MachineRecipes.generatorOutput();
        if (burnTicksLeft <= 0) {
            class_1799 fuel = method_5438(SLOT_INPUT_0);
            if (MachineRecipes.isFuel(fuel)) {
                burnTicksLeft = MachineRecipes.fuelTicks(fuel);
                fuel.method_7934(1);
                if (fuel.method_7960()) {
                    setSlotItem(SLOT_INPUT_0, class_1799.field_8037);
                }
                method_5431();
            } else {
                return;
            }
        } else {
            burnTicksLeft--;
        }

        addEnergy(output);
        distribute(level, pos, output);
    }

    private void distribute(class_1937 level, class_2338 pos, int amount) {
        for (class_2350 direction : class_2350.values()) {
            int toSend = Math.min(amount, getEnergy());
            if (toSend <= 0) {
                continue;
            }
            class_2586 neighbor = level.method_8321(pos.method_10093(direction));
            if (neighbor instanceof AbstractMachineBlockEntity machine && machine != this
                    && machine.getEnergy() < machine.getMaxEnergy()) {
                int accepted = machine.receiveEnergy(Math.min(toSend, (int) machine.getMaxEnergy() - machine.getEnergy()));
                if (accepted > 0) {
                    consumeEnergy(accepted);
                }
            }
        }
    }
}
