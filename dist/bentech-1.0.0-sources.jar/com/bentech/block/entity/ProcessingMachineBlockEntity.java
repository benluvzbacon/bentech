package com.bentech.block.entity;

import com.bentech.block.MachineBlock;
import com.bentech.block.MachineType;
import com.bentech.registry.ModBlockEntities;
import com.bentech.util.MachineRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import com.bentech.util.MachineRecipeResult;

/**
 * A machine that converts input item(s) into an output item over time while
 * consuming energy: macerator (ore -> dust), electric furnace (dust -> ingot),
 * compressor (ingot -> plate) and alloy smelter (two inputs -> alloy).
 */
public class ProcessingMachineBlockEntity extends AbstractMachineBlockEntity {

    private final class_1799[] items = {class_1799.field_8037, class_1799.field_8037, class_1799.field_8037};
    private final MachineType machineType;
    public int progress;

    public ProcessingMachineBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.PROCESSING, pos, state);
        this.machineType = state.method_26204() instanceof MachineBlock block ? block.getType() : MachineType.MACERATOR;
    }

    public MachineType getMachineType() {
        return machineType;
    }

    @Override
    protected class_1799 getSlotItem(int slot) {
        return slot >= 0 && slot < items.length ? items[slot] : class_1799.field_8037;
    }

    @Override
    protected void setSlotItem(int slot, class_1799 stack) {
        if (slot >= 0 && slot < items.length) {
            items[slot] = stack;
        }
    }

    @Override
    public long getMaxEnergy() {
        return MachineRecipes.maxEnergy(machineType);
    }

    @Override
    public boolean isActive() {
        return progress > 0;
    }

    @Override
    public void tickServer(class_1937 level, class_2338 pos, class_2680 state) {
        if (level == null || level.method_8608()) {
            return;
        }
        int ept = MachineRecipes.energyPerTick(machineType);
        class_1799 in0 = method_5438(SLOT_INPUT_0);
        class_1799 in1 = method_5438(SLOT_INPUT_1);
        class_1799 out = method_5438(SLOT_OUTPUT);

        MachineRecipeResult result = MachineRecipes.process(machineType, in0, in1);
        if (result == null || !canAccept(out, result.output())) {
            progress = 0;
            return;
        }
        if (!hasEnergy(ept)) {
            return;
        }
        consumeEnergy(ept);
        progress++;
        if (progress >= result.durationTicks()) {
            if (result.requiresTwoInputs()) {
                consumeOne(SLOT_INPUT_0);
                consumeOne(SLOT_INPUT_1);
            } else {
                consumeOne(SLOT_INPUT_0);
            }
            class_1799 output = result.output();
            class_1799 current = method_5438(SLOT_OUTPUT);
            if (current.method_7960()) {
                method_5447(SLOT_OUTPUT, output.method_7972());
            } else {
                current.method_7933(output.method_7947());
            }
            progress = 0;
            method_5431();
        }
    }

    private void consumeOne(int slot) {
        class_1799 stack = method_5438(slot);
        if (!stack.method_7960()) {
            stack.method_7934(1);
            if (stack.method_7960()) {
                setSlotItem(slot, class_1799.field_8037);
            }
            method_5431();
        }
    }

    private boolean canAccept(class_1799 current, class_1799 output) {
        if (current.method_7960()) {
            return true;
        }
        if (!current.method_31574(output.method_7909())) {
            return false;
        }
        return current.method_7947() + output.method_7947() <= current.method_7914();
    }
}
