package com.bentech.block.entity;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/**
 * Shared machinery base. Every machine holds a small internal "EU" energy
 * buffer and a fixed-size inventory. Slots 0/1 are inputs, slot 2 is output
 * (for generators slot 0 is the fuel input). Subclasses implement the per-tick
 * behaviour.
 */
public abstract class AbstractMachineBlockEntity extends class_2586 implements class_1263 {

    /** Input A / fuel. */
    public static final int SLOT_INPUT_0 = 0;
    /** Input B (alloy smelter). */
    public static final int SLOT_INPUT_1 = 1;
    /** Output. */
    public static final int SLOT_OUTPUT = 2;
    /** Total number of slots for all machines. */
    public static final int INVENTORY_SIZE = 3;

    protected int energy;

    protected AbstractMachineBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    // ------------------------------------------------------------------energy

    public abstract long getMaxEnergy();

    public int getEnergy() {
        return energy;
    }

    public boolean hasEnergy(int amount) {
        return energy >= amount;
    }

    public void setEnergy(int value) {
        int next = Math.max(0, Math.min((int) getMaxEnergy(), value));
        if (next != energy) {
            energy = next;
            method_5431();
        }
    }

    public void addEnergy(int amount) {
        setEnergy(energy + amount);
    }

    public void consumeEnergy(int amount) {
        setEnergy(energy - amount);
    }

    /** Returns the amount accepted (0 if the buffer is full). */
    public int receiveEnergy(int maxReceive) {
        int space = (int) getMaxEnergy() - energy;
        int accepted = Math.min(space, maxReceive);
        addEnergy(accepted);
        return accepted;
    }

    // ------------------------------------------------------------ processing

    public abstract boolean isActive();

    /** Runs once per server tick. */
    public abstract void tickServer(class_1937 level, class_2338 pos, class_2680 state);

    // ------------------------------------------------------------ Container

    @Override
    public int method_5439() {
        return INVENTORY_SIZE;
    }

    @Override
    public int method_5444() {
        return 64;
    }

    @Override
    public boolean method_5442() {
        for (int i = 0; i < method_5439(); i++) {
            if (!method_5438(i).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return switch (slot) {
            case SLOT_INPUT_0 -> getSlotItem(SLOT_INPUT_0);
            case SLOT_INPUT_1 -> getSlotItem(SLOT_INPUT_1);
            case SLOT_OUTPUT -> getSlotItem(SLOT_OUTPUT);
            default -> class_1799.field_8037;
        };
    }

    /** Subclasses own the actual item array. */
    protected abstract class_1799 getSlotItem(int slot);

    protected abstract void setSlotItem(int slot, class_1799 stack);

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 current = method_5438(slot);
        if (current.method_7960()) {
            return class_1799.field_8037;
        }
        int taken = Math.min(amount, current.method_7947());
        class_1799 result = current.method_7972();
        result.method_7939(taken);
        current.method_7934(taken);
        if (current.method_7960()) {
            setSlotItem(slot, class_1799.field_8037);
        }
        method_5431();
        return result;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 current = method_5438(slot);
        setSlotItem(slot, class_1799.field_8037);
        method_5431();
        return current;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        class_1799 copy = stack.method_7972();
        copy.method_7939(Math.min(copy.method_7947(), method_5444()));
        setSlotItem(slot, copy);
        method_5431();
    }

    @Override
    public void method_5431() {
        super.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        if (this.field_11863 == null) {
            return false;
        }
        return this.field_11863.method_8321(this.field_11867) == this
                && player.method_5649(
                        this.field_11867.method_10263() + 0.5,
                        this.field_11867.method_10264() + 0.5,
                        this.field_11867.method_10260() + 0.5) <= 64.0;
    }

    @Override
    public void method_5448() {
        for (int i = 0; i < method_5439(); i++) {
            setSlotItem(i, class_1799.field_8037);
        }
    }

    // ------------------------------------------------------------------- NBT

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569("energy", energy);
        class_2499 list = new class_2499();
        for (int i = 0; i < method_5439(); i++) {
            class_2487 itemTag = new class_2487();
            class_1799 stack = getSlotItem(i);
            if (!stack.method_7960()) {
                stack.method_57376(registries, itemTag);
            }
            list.add(itemTag);
        }
        tag.method_10566("items", list);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        energy = tag.method_10550("energy");
        class_2499 list = tag.method_10554("items", class_2520.field_33260);
        for (int i = 0; i < method_5439(); i++) {
            if (i >= list.size()) {
                setSlotItem(i, class_1799.field_8037);
                continue;
            }
            class_2487 itemTag = list.method_10602(i);
            setSlotItem(i, class_1799.method_57360(registries, itemTag).orElse(class_1799.field_8037));
        }
    }

    // ---------------------------------------------------------------- ticker

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, AbstractMachineBlockEntity blockEntity) {
        blockEntity.tickServer(level, pos, state);
    }
}
