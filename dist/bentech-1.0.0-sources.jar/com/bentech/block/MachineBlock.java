package com.bentech.block;

import com.bentech.block.entity.AbstractMachineBlockEntity;
import com.bentech.block.entity.GeneratorBlockEntity;
import com.bentech.block.entity.ProcessingMachineBlockEntity;
import com.bentech.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5558;

/**
 * A machine block. Right-clicking inserts the held item into the first empty
 * input slot (or, with shift, extracts the output). Machines are also fully
 * automatable with hoppers.
 */
public class MachineBlock extends class_2237 {

    private final MachineType type;

    public MachineBlock(class_4970.class_2251 properties, MachineType type) {
        super(properties);
        this.type = type;
    }

    public MachineType getType() {
        return type;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(props -> new MachineBlock(props, type));
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        if (type.getKind() == MachineType.MachineKind.GENERATOR) {
            return new GeneratorBlockEntity(pos, state);
        }
        return new ProcessingMachineBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        if (level.method_8608()) {
            return null;
        }
        if (blockEntityType == ModBlockEntities.GENERATOR) {
            return method_31618(blockEntityType, ModBlockEntities.GENERATOR, AbstractMachineBlockEntity::tick);
        }
        return method_31618(blockEntityType, ModBlockEntities.PROCESSING, AbstractMachineBlockEntity::tick);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos,
                                               class_1657 player, class_3965 hit) {
        if (level.method_8608()) {
            return class_1269.field_5812;
        }
        if (!(level.method_8321(pos) instanceof AbstractMachineBlockEntity machine)) {
            return class_1269.field_5811;
        }
        class_1799 handStack = player.method_5998(class_1268.field_5808);
        if (player.method_5715()) {
            class_1799 out = machine.method_5438(AbstractMachineBlockEntity.SLOT_OUTPUT);
            if (!out.method_7960()) {
                machine.method_5447(AbstractMachineBlockEntity.SLOT_OUTPUT, class_1799.field_8037);
                if (!player.method_31548().method_7394(out)) {
                    player.method_7328(out, false);
                }
            } else {
                player.method_7353(class_2561.method_43471("message.bentech.no_output"), true);
            }
            return class_1269.method_29236(true);
        }
        if (!handStack.method_7960()) {
            int slot = slotForInsert(machine);
            if (slot >= 0) {
                class_1799 toInsert = handStack.method_7972();
                toInsert.method_7939(1);
                machine.method_5447(slot, toInsert);
                handStack.method_7934(1);
            } else {
                player.method_7353(class_2561.method_43471("message.bentech.input_full"), true);
            }
            return class_1269.method_29236(true);
        }
        player.method_7353(class_2561.method_43470(
                type.getDisplayName() + ": " + machine.getEnergy() + "/" + machine.getMaxEnergy() + " EU "
                        + (machine.isActive() ? "(active)" : "(idle)")), true);
        return class_1269.method_29236(true);
    }

    private int slotForInsert(AbstractMachineBlockEntity machine) {
        if (machine.method_5438(AbstractMachineBlockEntity.SLOT_INPUT_0).method_7960()) {
            return AbstractMachineBlockEntity.SLOT_INPUT_0;
        }
        if (machine.method_5438(AbstractMachineBlockEntity.SLOT_INPUT_1).method_7960()) {
            return AbstractMachineBlockEntity.SLOT_INPUT_1;
        }
        return -1;
    }
}
