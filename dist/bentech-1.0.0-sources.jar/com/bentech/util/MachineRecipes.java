package com.bentech.util;

import com.bentech.api.Material;
import com.bentech.api.Materials;
import com.bentech.block.MachineType;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Central catalogue of machine recipes (code-defined, matching the classic
 * GregTech processing chain):
 *
 * <ul>
 *   <li>Macerator: ore block -> 2 x dust</li>
 *   <li>Electric furnace: dust -> ingot</li>
 *   <li>Compressor: ingot -> plate</li>
 *   <li>Alloy smelter: two components -> a metal dust</li>
 *   <li>Generator: burnable fuel -> energy</li>
 * </ul>
 *
 * The maps are built by {@link #build()} once all items/blocks are registered.
 */
public final class MachineRecipes {

    private static final Map<class_1792, class_1792> MACERATE = new HashMap<>();
    private static final Map<class_1792, class_1792> SMELT = new HashMap<>();
    private static final Map<class_1792, class_1792> COMPRESS = new HashMap<>();
    private static final Map<ItemCombination, class_1792> ALLOY = new HashMap<>();
    private static final Map<class_1792, Integer> FUEL_TICKS = new HashMap<>();

    private MachineRecipes() {
    }

    public static void build() {
        MACERATE.clear();
        SMELT.clear();
        COMPRESS.clear();
        ALLOY.clear();
        FUEL_TICKS.clear();

        for (Material m : Materials.all()) {
            if (m.ore != null) {
                MACERATE.put(m.ore, m.dust);
            }
            if (m.dust != null && m.ingot != null) {
                SMELT.put(m.dust, m.ingot);
            }
            if (m.ingot != null && m.plate != null) {
                COMPRESS.put(m.ingot, m.plate);
            }
        }

        ALLOY.put(ItemCombination.of(Materials.Copper.dust, Materials.Tin.dust), Materials.Bronze.dust);
        ALLOY.put(ItemCombination.of(Materials.Iron.dust, class_1802.field_8713), Materials.Steel.dust);
        ALLOY.put(ItemCombination.of(Materials.Iron.dust, Materials.Nickel.dust), Materials.Invar.dust);
        ALLOY.put(ItemCombination.of(Materials.Copper.dust, Materials.Zinc.dust), Materials.Brass.dust);

        FUEL_TICKS.put(class_1802.field_8713, 400);
        FUEL_TICKS.put(class_1802.field_8665, 400);
        FUEL_TICKS.put(class_1802.field_8797, 3600);
        FUEL_TICKS.put(class_1802.field_8187, 3600);
    }

    /** Returns the recipe for a machine, or null if none applies. */
    public static MachineRecipeResult process(MachineType type, class_1799 in0, class_1799 in1) {
        if (in0 == null || in0.method_7960()) {
            return null;
        }
        return switch (type) {
            case MACERATOR -> single(MACERATE.get(in0.method_7909()), 2, durationTicks(type));
            case ELECTRIC_FURNACE -> single(SMELT.get(in0.method_7909()), 1, durationTicks(type));
            case COMPRESSOR -> single(COMPRESS.get(in0.method_7909()), 1, durationTicks(type));
            case ALLOY_SMELTER -> {
                if (in1 == null || in1.method_7960()) {
                    yield null;
                }
                class_1792 out = ALLOY.get(ItemCombination.of(in0.method_7909(), in1.method_7909()));
                yield out == null ? null : new MachineRecipeResult(new class_1799(out, 2), durationTicks(type), true);
            }
            default -> null;
        };
    }

    private static MachineRecipeResult single(class_1792 out, int count, int ticks) {
        return out == null ? null : new MachineRecipeResult(new class_1799(out, count), ticks, false);
    }

    public static int durationTicks(MachineType type) {
        return switch (type) {
            case ALLOY_SMELTER -> 300;
            default -> 200;
        };
    }

    public static int energyPerTick(MachineType type) {
        return switch (type) {
            case ALLOY_SMELTER -> 2;
            default -> 1;
        };
    }

    public static long maxEnergy(MachineType type) {
        return switch (type) {
            case ALLOY_SMELTER -> 4096;
            default -> 2048;
        };
    }

    /** Generator energy output (EU per tick while burning). */
    public static int generatorOutput() {
        return 32;
    }

    public static int fuelTicks(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return 0;
        }
        return FUEL_TICKS.getOrDefault(stack.method_7909(), 0);
    }

    public static boolean isFuel(class_1799 stack) {
        return fuelTicks(stack) > 0;
    }

    public record ItemCombination(class_1792 a, class_1792 b) {
        public static ItemCombination of(class_1792 x, class_1792 y) {
            // order independent so (copper, tin) == (tin, copper)
            class_2960 rx = class_7923.field_41178.method_10221(x);
            class_2960 ry = class_7923.field_41178.method_10221(y);
            String sx = rx == null ? String.valueOf(System.identityHashCode(x)) : rx.toString();
            String sy = ry == null ? String.valueOf(System.identityHashCode(y)) : ry.toString();
            return sx.compareTo(sy) <= 0 ? new ItemCombination(x, y) : new ItemCombination(y, x);
        }
    }
}
