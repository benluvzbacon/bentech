package com.bentech.util;

import net.minecraft.class_1799;

/**
 * Describes the outcome of a machine recipe: the output stack, how many ticks
 * the operation takes and whether it consumes two input slots.
 */
public record MachineRecipeResult(class_1799 output, int durationTicks, boolean requiresTwoInputs) {
}
